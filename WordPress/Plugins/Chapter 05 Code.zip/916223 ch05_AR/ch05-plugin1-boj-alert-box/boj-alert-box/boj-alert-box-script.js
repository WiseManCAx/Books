/**
 * Displays an alert box with our first translated message when called.
 */
function boj_show_alert_box_1() {
	alert( boj_alert_box_L10n.boj_box_1 );
}

/**
 * Displays an alert box with our second translated message when called.
 */
function boj_show_alert_box_2() {
	alert( boj_alert_box_L10n.boj_box_2 );
}