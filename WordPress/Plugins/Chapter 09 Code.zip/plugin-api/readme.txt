Note: for testing purpose, the API says there's a new version 2.0 of the plugin,
but the zip package contains the same version 1.0 so you can upgrade again and again.