These files contain the source code for the examples contained in Chapters 8 and 10 of "Professional WordPress: Design and Development, Second Edition"
(ISBN: 9781118442272).


The source code is for your convenience purposes only. The source code is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF 
ANY KIND, either express or implied.


All of the examples discussed in this book were written for use on a variety of systems and devices. While every effort has been made to ensure that
the screen shots are as up to date as possible, the actual screen that you see will depend on the system or device you are using.
