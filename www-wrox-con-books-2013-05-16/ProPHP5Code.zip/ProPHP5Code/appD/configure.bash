#!/bin/bash
./configure --with-apache=../apache_1.3.31 --with-libxml-dir=/usr/local/lib --with-gd --with-gettext --without-mysql --with-pgsql --enable-sockets --with-jpeg-dir=/usr/local/lib --with-png-dir=/usr/local/lib --with-zlib-dir=/usr/local/lib --enable-gd-native-ttf --with-freetype-dir=/usr/local/lib --with-xmlrpc --with-dom �-enable-xslt --with-expat-dir=/usr/local/lib --with-xsl
