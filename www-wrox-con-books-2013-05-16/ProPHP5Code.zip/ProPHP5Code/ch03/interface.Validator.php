<?php
  interface Validator {
    abstract function validate();
  }
?>
