<?php

  class Demo {

    public $name;

    function sayHello() {
      print "Hello $this->name!";
    }
  }
?>
