<?php

  interface Openable {
    abstract function open();
    abstract function close();
  }

?>
