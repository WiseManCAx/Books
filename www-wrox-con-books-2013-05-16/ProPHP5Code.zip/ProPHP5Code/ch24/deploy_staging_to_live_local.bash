#!/bin/bash
rsync �avr /home/widgets/staging/* /home/widgets/live