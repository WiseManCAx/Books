CREATE TABLE "mytable" (
  "id" SERIAL PRIMARY KEY NOT NULL, 
  "myval" varchar(255)
);
