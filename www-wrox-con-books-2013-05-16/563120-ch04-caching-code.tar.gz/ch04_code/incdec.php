<?php

$memc = new Memcached('mymemc');

# prefix every item key with "myapp:"
$memc->setOption(Memcached::OPT_PREFIX_KEY, "myapp:");

# set server distribution to consistent hashing
$memc->setOption(Memcached::OPT_DISTRIBUTION, Memcached::DISTRIBUTION_CONSISTENT);

# two servers in the pool
$servers = array (
array ('192.168.1.106', 11211),
array ('127.0.0.1', 11211)
);

# now add the servers
$memc->addServers($servers);
$memc->addServer('192.168.1.125', 11211);

if ($memc->set('counter', 1)) {
  echo $memc->increment('counter') . "\n";
  echo $memc->increment('counter', 10) . "\n";
  echo $memc->decrement('counter') . "\n";
  echo $memc->decrement('counter', 5) . "\n";
}

?>
