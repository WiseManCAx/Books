<?php

function rand_str($len = 16)
{
    $chars_len = (strlen($chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890') - 1);

    $str = ''; 
   
    for ($i = 1; $i <= $len; $i++) {
        $rand_char = $chars{rand(0, $chars_len)};
       
        if ($rand_char != $str{$i - 1}) { 
          $str .=  $rand_char;
        }
        else {
          $i--;
        }
    }
   
    return $str;
}

// new Memcached instance
$memc = new Memcached();

// find out the current distribution type
$distribution = $memc->getOption(Memcached::OPT_DISTRIBUTION);

// since the value is numeric, set to a text value 
$distribution = $distribution == Memcached::DISTRIBUTION_CONSISTENT ? 
                                        "CONSISTENT, KETAMA" : "MODULA";

echo "The distribution is currently: $distribution\n";

$memc->setOption(Memcached::OPT_DISTRIBUTION, Memcached::DISTRIBUTION_CONSISTENT);

$distribution = $memc->getOption(Memcached::OPT_DISTRIBUTION);
$distribution = $distribution == Memcached::DISTRIBUTION_CONSISTENT ? 
                                        "CONSISTENT, KETAMA" : "MODULA";

echo "The distribution is now set to: $distribution\n";

// a very cool feature is setting the serializer to JSON
$memc->setOption(Memcached::OPT_SERIALIZER, MEMCACHED_SERIALIZER_JSON);

# two servers in the pool
$servers = array (
    array ('192.168.1.106', 11211),
    array ('127.0.0.1', 11211)
);

# now add the servers
$memc->addServers($servers);
$memc->addServer('192.168.1.125', 11211);

// set a value
if ($memc->set('t1', $servers)) {
  // if true, success setting  
  echo "t1 was set.\n";
}
else {
  // if falsed, failed to set
  echo "failed to set t1\n";
}
$memc->set('t10', array( 'foo' => array('one' => 1, 'two' => 2), 'fee' => array('three' => 3, 'four' => 4))); 

$foo = $memc->get('t10');
print_r($foo);


// now fetch t1
$t1= $memc->get('t1');

$result_code= $memc->getResultCode;
if ($result_code == Memcached::RES_SUCCESS) {
  print_r($t1);
}
elseif ($result_code == Memcached::RES_NOTFOUND) {
  print "t1 not found\n";
}

#$memc->delete('t1');


?>
