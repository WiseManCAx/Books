<?php

function rand_str($len = 16)
{
    $chars_len = (strlen($chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890') - 1);

    $str = ''; 
   
    for ($i = 1; $i <= $len; $i++) {
        $rand_char = $chars{rand(0, $chars_len)};
       
        if ($rand_char != $str{$i - 1}) { 
          $str .=  $rand_char;
        }
        else {
          $i--;
        }
    }
   
    return $str;
}

// new Memcached instance
$memc = new Memcached();

// find out the current distribution type
$distribution = $memc->getOption(Memcached::OPT_DISTRIBUTION);

// since the value is numeric, set to a text value 
$distribution = $distribution == Memcached::DISTRIBUTION_CONSISTENT ? 
                                        "CONSISTENT, KETAMA" : "MODULA";

echo "The distribution is currently: $distribution\n";

$memc->setOption(Memcached::OPT_DISTRIBUTION, Memcached::DISTRIBUTION_CONSISTENT);

$distribution = $memc->getOption(Memcached::OPT_DISTRIBUTION);
$distribution = $distribution == Memcached::DISTRIBUTION_CONSISTENT ? 
                                        "CONSISTENT, KETAMA" : "MODULA";

echo "The distribution is now set to: $distribution\n";

// a very cool feature is setting the serializer to JSON
$memc->setOption(Memcached::OPT_SERIALIZER, MEMCACHED_SERIALIZER_JSON);

# two servers in the pool
$servers = array (
    array ('192.168.1.106', 11211),
    array ('127.0.0.1', 11211)
);

# now add the servers
$memc->addServers($servers);
$memc->addServer('192.168.1.125', 11211);

$stats_ar = $memc->getStats();

print_r($stats_ar);

?>
