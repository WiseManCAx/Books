<?php

require_once 'rand.php';
# setting id 'mymemc'
$memc = new Memcached('mymemc');

# two servers in the pool
$servers = array (
array ('192.168.1.106', 11211),
array ('192.168.1.125', 11211),
array ('127.0.0.1', 11211),
);

# now add the servers
$memc->addServers($servers);
$key_list = array();

$server_keys = array('serverA', 'serverB', 'serverC');
// loop through for each server key
foreach ($server_keys as $server_key) {
  // loop through, assigning 
  $items = array();
  for ($i = 0; $i < 4; $i++) {
    // use a random string for the key
    $key = "$server_key:" . rand_str(8);
    $items[$key] = "value for $key";
  }
  $key_list[$server_key] = $items;
  $memc->setMultiByKey($server_key, $items);
}
foreach ($server_keys as $server_key) {
  // loop through, assigning 
  $items = array();
  $keys = array_keys($key_list[$server_key]);
  $items = $memc->getMultiByKey($server_key, $keys);
  var_dump($items);
}


?>
