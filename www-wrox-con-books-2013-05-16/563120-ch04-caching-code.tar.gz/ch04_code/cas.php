<?php

function rand_str($len = 16)
{
    $chars_len = (strlen($chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890') - 1);

    $str = ''; 
   
    for ($i = 1; $i <= $len; $i++) {
        $rand_char = $chars{rand(0, $chars_len)};
       
        if ($rand_char != $str{$i - 1}) { 
          $str .=  $rand_char;
        }
        else {
          $i--;
        }
    }
   
    return $str;
}

# setting id 'mymemc'
$memc = new Memcached('mymemc');
$memc2 = new Memcached('mymemc2');

# two servers in the pool
$servers = array (
    array ('192.168.1.106', 11211),
    array ('127.0.0.1', 11211)
);

# now add the servers
$memc->addServers($servers);
$memc->addServer('192.168.1.125', 11211);
$memc2->addServers($servers);
$memc2->addServer('192.168.1.125', 11211);

// set a value
if ($memc->set('t1', 'initialy set value')) {
  // if true, success setting  
  echo "t1 initially set.\n";
}
else {
  // if falsed, failed to set
  echo "failed to set t1\n";
}

// now fetch t1
if ($t1= $memc->get('t1', null, $cas)) {
  print "t1 value is '$t1'\n";
}
elseif ($memc->getResultCode() == Memcached::NOT_FOUND) {
  print "t1 not found\n";
}
echo "cas value $cas\n";

// did anyone else change it since?
sleep(2);
if ($memc->cas($cas, 't1', 'a new value using cas')) {
  echo "t1 set with cas\n";
}
else {
  echo "t1 not set with cas\n";
}
// now fetch t1 again
if ($t1= $memc->get('t1', null, $cas)) {
  echo "t1 value is '$t1'\n";
}
elseif ($memc->getResultCode() == Memcached::NOT_FOUND) {
  echo "t1 not found\n";
}
echo "cas value $cas\n";

sleep(2);
// another client, t2 is setting
echo "memc2 is setting t1\n";
$memc2->set('t1', 'memc2 changed me');
sleep(2);
// did anyone else change it since?
sleep(2);

// this should not succeed
if ($memc->cas($cas, 't1', 'check if cas can set')) {
  echo "t1 set with cas\n";
}
else {
  echo "t1 not set with cas\n";
}


$memc->delete('t1');


?>
