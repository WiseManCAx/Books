<?php

function rand_str($len = 16)
{
    $chars_len = (strlen($chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890') - 1);

    $str = ''; 
   
    for ($i = 1; $i <= $len; $i++) {
        $rand_char = $chars{rand(0, $chars_len)};
       
        if ($rand_char != $str{$i - 1}) { 
          $str .=  $rand_char;
        }
        else {
          $i--;
        }
    }
   
    return $str;
}

function displayRss($rss = '') {
  echo $rss;
}
function getNewRssEntry() {
  return "
<item>
    <guid isPermaLink='true'>http://mysite.com/14.html</guid>
    <pubDate>Sat, 02 Oct 2009 21:50:00 GMT</pubDate>
    <title>Saturday night live</title>
    <author>me@mysite.com</author>
    <link>http://mysite.com/14.html</link>
    <description>Out dancing tonight! Went clubbing down in Portsmouth.</description>
    <comments>http://mysite.com/14.html</comments>
    <category>fun</category>
  </item>
";

}
# setting id 'mymemc'
$memc = new Memcached('mymemc');

# prefix every item key with "myapp:"
$memc->setOption(Memcached::OPT_PREFIX_KEY, "myapp:");

# set server distribution to consistent hashing
$memc->setOption(Memcached::OPT_DISTRIBUTION, Memcached::DISTRIBUTION_CONSISTENT);


# two servers in the pool
$servers = array (
array ('192.168.1.106', 11211),
array ('127.0.0.1', 11211)
);

$entries = "
  <item>
    <guid isPermaLink='true'>http://mysite.com/12.html</guid>
    <pubDate>Fri, 02 Oct 2009 13:32:07 GMT</pubDate>
    <title>Coding PHP and MySQL with Memcached</title>
    <author>me@mysite.com</author>
    <link>http://mysite.com/12.html</link>
    <description>Having fun adding caching to my app code</description>
    <comments>http://mysite.com/12.html</comments>
    <category>dev</category>
  </item>
  <item>
    <guid isPermaLink='true'>http://mysite.com/11.html</guid>
    <pubDate>Fri, 02 Oct 2009 08:10:31 GMT</pubDate>
    <title>Morning entry</title>
    <author>me@mysite.com</author>
    <link>http://mysite.com/11.html</link>
    <description>This is my morning entry. I just woke up and am drinking my tea.</description>
    <comments>http://mysite.com/11.html</comments>
    <category>morning</category>
  </item>
";

# now add the servers
$memc->addServers($servers);
$memc->addServer('192.168.1.125', 11211);

// turn compression off 
$memc->setOption(Memcached::OPT_COMPRESSION, false);
$memc->set('rss_entries', $entries);
$entries = '';
$header = "<rss version='2.0'>\n  <channel>\n";
$footer = "  <channel>\n</rss>\n";

// get a new rss entry
$entry = getNewRssEntry();
echo "entry $entry\n";

// prepend to the beginning of the entries
if ($memc->prepend('rss_entries', $entry)) {
  echo "prepended\n";
}
else {
  echo "not prepended.\n";
}

// get the entries
$entries = $memc->get('rss_entries');

// display the entries, should have the new entry at the beginning
displayRss($header . $entries . $footer);




