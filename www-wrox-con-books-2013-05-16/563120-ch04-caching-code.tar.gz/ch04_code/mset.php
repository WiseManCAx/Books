<?php

# setting id 'mymemc'
$memc = new Memcached('mymemc');

# prefix every item key with "myapp:"
$memc->setOption(Memcached::OPT_PREFIX_KEY, "myapp:");

# set server distribution to consistent hashing
$memc->setOption(Memcached::OPT_DISTRIBUTION, Memcached::DISTRIBUTION_CONSISTENT);

# two servers in the pool
$servers = array (
array ('192.168.1.106', 11211),
array ('127.0.0.1', 11211)
);

# now add the servers
$memc->addServers($servers);
$memc->addServer('192.168.1.125', 11211);

$items = array ();
// build up the associative array  
for ($i = 1; $i <= 5; $i++) {
  $items["t$i"] = "$i: some value";
}

// multi-set each item of the array
$memc->setMulti($items);

// You can perform a multi-get
$null_val = null;
$t_array = $memc->getMulti( array ('t5','t3','t1'), 
                            $null_val, 
                            Memcached::GET_PRESERVE_ORDER);

// just as before, you have an array of the keys you requested
print_r($t_array);

// or get each item individually  
for ($i = 1; $i <= 5; $i++) {
  $val = $memc->get("t$i");
  print "$val\n";
}

