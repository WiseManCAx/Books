<?php

# setting id 'mymemc'
$memc = new Memcached('mymemc');

# two servers in the pool
$servers = array (
    array ('192.168.1.106', 11211),
    array ('127.0.0.1', 11211),
    array ('192.168.1.125', 11211)
);
$memc->addServers($servers);


// set a value
if ($memc->set('t1', 'initialy set value')) {
  echo "sucess setting\n";
}
elseif ($memc->getResultCode() == Memcached::RES_NOTSTORED) {
  echo "'t1' was not set\n";
}

echo "return message from set operation was: " . $memc->getResultMessage() . "\n";

$t1= $memc->get('t1', null, $cas);
echo "return message from get operation was: " . $memc->getResultMessage() . "\n";

if ($memc->add('t1', 'added value should not work')) {
  echo "sucess adding\n";
}
elseif ($memc->getResultCode() == Memcached::RES_NOTSTORED) {
  echo "'t1' was not added\n";
}
echo "return message from add operation was: " . $memc->getResultMessage() . "\n";

$memc->delete('t1');
$t1= $memc->get('t1', null, $cas);
echo "return message from get operation was: " . $memc->getResultMessage() . "\n";


?>
