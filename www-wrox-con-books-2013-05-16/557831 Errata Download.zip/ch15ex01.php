<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFFFFF">
<form method="POST" action="ch04ex01.php">
  <table width="100%" border="0" cellpadding="6">
    <tr> 
      <td><b><font face="Arial, Helvetica, sans-serif">Welcome to Beginning PHP5</font></b></td>
      <td><b><font face="Arial, Helvetica, sans-serif">Chapter 15</font></b></td>
      <td><b><font face="Arial, Helvetica, sans-serif">Exercise 01</font></b></td>
    </tr>
    <tr> 
      <td colspan="3"> 
        <p><font face="Arial, Helvetica, sans-serif" size="-1">Please use this 
          form to send emails to everyone on the list:</font></p>
        <table width="70%" border="0" cellpadding="6" align="center">
          <tr> 
            <td>
              <p><font face="Arial, Helvetica, sans-serif" size="-1">Enter the 
                Email Greeting, Body, and Regards Here: </font></p>
              <p>
                <textarea name="email_body" cols="50" rows="4"></textarea>
              </p>
            </td>
          </tr>
          <tr align="right"> 
            <td> 
              <input type="submit" name="send_email" value="Send Email">
            </td>
          </tr>
        </table>
        
      </td>
    </tr>
  </table>
</form>
</body>
</html>
