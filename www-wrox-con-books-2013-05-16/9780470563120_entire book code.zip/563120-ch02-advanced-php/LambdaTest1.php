<?php
$x = function($number) {
  return $number * 10;
};
echo $x(8); // Output: 80
?>