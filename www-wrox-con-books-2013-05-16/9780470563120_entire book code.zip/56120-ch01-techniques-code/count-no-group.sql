SELECT country, COUNT(*)
FROM   flags;

