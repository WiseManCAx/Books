<?php

abstract class AbstractCar {
  public abstract function getPrice();
  public abstract function getManifacturer();
};

?>