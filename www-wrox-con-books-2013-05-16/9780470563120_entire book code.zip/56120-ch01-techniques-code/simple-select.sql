SELECT color
FROM flags
WHERE country='USA';
