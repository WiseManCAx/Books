<?php

include_once("GDImage.class.php");

$image = GDImage::createImage("test.png");

?>
