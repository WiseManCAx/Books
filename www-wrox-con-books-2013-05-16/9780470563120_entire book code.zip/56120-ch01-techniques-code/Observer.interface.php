<?php
interface Observer {
  public function notify( $event );
};
?>
