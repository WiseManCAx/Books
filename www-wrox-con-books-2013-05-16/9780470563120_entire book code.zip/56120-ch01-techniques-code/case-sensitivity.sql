SELECT 'USA' = 'USA', 'USA' = 'Usa', 'USA' = 'usa', 
       'USA' = 'usa' COLLATE latin1_general_cs AS different;
