<?php
include_once("ReadableNode.interface.php");
include_once("Node.class.php");
include_once("ForumTopic.class.php");

$forum = new ForumTopic();
?>
