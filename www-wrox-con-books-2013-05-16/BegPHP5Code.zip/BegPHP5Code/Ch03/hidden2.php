<html>
<head><title></title></head>
<body>
<?php
echo "The three options were:<br>";
echo "$_GET[Hidden1]<br>";
echo "$_GET[Hidden2]<br>";
echo "$_GET[Hidden3]<br>";
echo "<br>You selected:<br>";
echo "$_GET[ListBox]";
?>
</body>
</html>
