<html>
<head><title></title></head>
<body>
<?php
echo $_POST['Choice'];
?>
</body>
</html>
