<?php
echo $_POST;
?>
