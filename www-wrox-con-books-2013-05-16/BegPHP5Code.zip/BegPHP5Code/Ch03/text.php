<html>
<head><title</title></head>
<body>
Your favorite author is:
<?php 
echo $_GET['Author'];
?>
</body>
</html>
