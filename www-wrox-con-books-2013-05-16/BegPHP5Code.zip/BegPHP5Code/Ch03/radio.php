<html>
<head><title></title></head>
<body>
<?php
echo "You selected the answer: $_GET[Question1]";
?>
</body>
</html>
