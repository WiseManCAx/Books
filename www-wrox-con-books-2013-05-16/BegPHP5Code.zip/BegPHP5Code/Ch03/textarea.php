<html>
<head><title></title></head>
<body>
Your favorite web sites are:
<?php
echo $_POST['WebSites'];
?>
</body>
</html>
