<?php
echo "<PRE>";
print_r($GLOBALS);
echo "</pre>";
?>
