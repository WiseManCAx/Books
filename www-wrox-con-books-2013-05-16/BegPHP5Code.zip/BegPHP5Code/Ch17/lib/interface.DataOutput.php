<?

interface DataOutput
{

    /**
     * Defines a simple HTML output function, would switch to something 
     * like a template when multiple output types appear.
     */
    abstract function toHTML();
}

?>