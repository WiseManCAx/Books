<? 
$GLOBALS['basepath'] = "/var/www/casestudy-c17/";
$GLOBALS['baseurl'] = "http://localhost/casestudy-c17/";

$GLOBALS['dbpath'] = "/var/www/casestudy-c17/logs/";  // keep out of webroot
$GLOBALS['dbname'] = "sitelogs.db";                   // final slash required

$GLOBALS['smarty-path']=$GLOBALS['basepath']."/lib/smarty/";

$GLOBALS['maxdemo'] = 1024;



?>
