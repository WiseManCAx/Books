
<h3>Options</3>
<ul>
<li><a href="setup.php">Initialize database</a> (warning, will delete data!)
<li><a href="lib/test.UserLog.php">Run UserLog test suite</a>
<li><a href="lib/test.LogContainer.php">Run LogContainer test suite</a>
<li><a href="lib/test.UserDemographic.php">Run UserDemographic test suite</a>
<li><a href="post.php">Post logging data</a>
<li><a href="report.php">View reports</a>
</ul>