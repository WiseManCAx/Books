<? 

require ("settings.php");

$GLOBALS['dbname'] = "sitelogs-test.db";

?>
