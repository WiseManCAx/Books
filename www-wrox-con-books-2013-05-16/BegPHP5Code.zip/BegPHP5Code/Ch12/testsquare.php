<?php
require_once ('class.Square.php');
$obj = new Square(7);
$a = $obj->getArea();
echo "$a";
?>
