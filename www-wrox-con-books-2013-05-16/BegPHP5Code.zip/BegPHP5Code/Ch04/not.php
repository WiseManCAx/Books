<?php
$a = 10;
$b = 12;
If (0 or ($a == ($b - 44))) { echo "Always true"; }
?>