<?php
$var = false;
echo "$var";
print $var;
?>
