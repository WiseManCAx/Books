<?php

class emailException extends Exception 
{
  function __construct($message) 
  {
    echo "There was an error sending your email: <br \>";
    echo $message;
  }
}

function sendEmail($to, $subject, $message) 
{
  if ($to == NULL) 
  {
     throw new emailException ("Recipient email address is NULL");
  }
  
  mail($to, $subject, $message);
}

try 
{
  sendEmail("", "Exception Testing",
            "We are testing the exception handling in PHP5");
} 
catch (emailException $e) 
{
  echo " in file <strong>" . $e->getFile() . "</strong>";
  echo " on line <strong>" . $e->getLine() . "</strong>";
}

?>
