<?php

function lastResort ($e) 
{
  echo "Previously uncaught exception being caught from " . get_class($e);
  echo " in file: " . $e->getFile() . " on line " . $e->getLine();
}

set_exception_handler("lastResort");

throw new Exception();

?>
