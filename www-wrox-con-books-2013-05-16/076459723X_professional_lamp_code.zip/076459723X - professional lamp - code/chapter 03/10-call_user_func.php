<?php
class foo
{

public function bar($a, $b)
{
    echo "I'm here! $a! $b! And all that!";
}

}

$t = new foo;
$x = array($t, 'bar');
$x('1066', '42');
?>
