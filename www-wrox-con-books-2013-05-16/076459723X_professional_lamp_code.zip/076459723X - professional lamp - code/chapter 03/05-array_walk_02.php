<?php

function imagedatapoints($image, $datapoints)
{
    foreach($datapoints as $datapoint)
    {
    $width = $height = $datapoint[2]*2;
        imageellipse($image, $datapoint[0], $datapoint[1], $width, $height, 
                     $datapoint[3]);
    }
}
imagedatapoints($image, $datapoint);

?>