<?php

$data_points = array(
    array(10,10,5, $palette['black']),
    array(10,20,5, $palette['black']),
    array(20,13,5, $palette['darkolivegreen'])
);

function imagedatapoint($image, $datapoint)
{
    $width = $height = $datapoint[2]*2;
    imageellipse($image, $datapoint[0], $datapoint[1], $width, $height, 
                 $datapoint[3]);
}

foreach($datapoints as $datapoint)
{
    imagedatapoint($image, $datapoint);
}

?>