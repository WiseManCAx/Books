<?php
function lambda_1($a)
{
    return $a;
}
$anonymous_function = create_function('$a', 'return strrev($a);');
echo "The anonymous function has been named $anonymous_function.\n";
$use_this = 'lambda_1';
echo $use_this('generic string'), "\n";
$use_this = $anonymous_function;
echo $use_this('generic string'),"\n";
?>
