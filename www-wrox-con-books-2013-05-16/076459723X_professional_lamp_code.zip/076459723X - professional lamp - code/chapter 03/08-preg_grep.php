<?php

// This use of preg_grep takes a listing of the current directory, and retains only 
// those file names that end with four digits followed by "“.jpg" or ".jpeg".
$images = preg_grep('/\d{4}\.jpe?g$/', scandir('.'));
 
?>