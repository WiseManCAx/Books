<?php

$new_array = array_map('func', $arr1, $arr2);

?>