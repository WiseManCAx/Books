<?php

preg_replace_callback('/\S+@\S+/', $text, 'wrap_emails');

function wrap_emails($possible_match)
{
    $possible_email = $possible_match[0]; // The callback will be passed an array
    if(is_rfc822_compliant($possible_email)) // A hypothetical function that
                                             // does all the boring stuff
        return '<a href="mailto:'.$possible_email.'">'.$possible_email.'</a>';
    else
        return $possible_email; // Not an email, return the substring unchanged.
}

function include_templates($template_name)
{
   if(is_string($template_file))
       $template_file = $template_name;
   else
       $template_file = $template_name[1].'.tpl';   $template = file_get_contents($template_file);
   return preg_replace_callback('\{include:\s*([^\s}]+)\}', 'include_templates', 
                                $template);
}

function collect_email($possible_match)
{
    $possible_email = $possible_match[0];
    if(self::is_rfc822_compliant($possible_email))
        $this->emails = $possible_email;
    return $possible_email; // Return the match unchanged 
}

?>