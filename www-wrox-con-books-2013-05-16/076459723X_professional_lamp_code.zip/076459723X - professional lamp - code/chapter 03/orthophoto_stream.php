<?php
/*
** The orthophoto stream uses the Orthophoto dataset maintained by
** Land Information New Zealand.The photoset follows the Topographic
** Map 260 series; coordinates used are those of the New Zealand
** Map Grid (NZMG), a system unique to that country.
**
** Aerial photos have a resolution of 2.5m per pixel, with an
** accuracy of ±12.5m.
*/

class orthophoto_stream
{
    // This is the generated PNG data that will be fed
    // back by the stream.
    private $png_data;
    
    // For the ftell() function / stream_tell() method.
    private $data_length;
    
function stream_open($path, $mode, $options, &$opened_path)
{
    // This is a read-only stream
    if(preg_match('/[w+a]/', $options)) return false;
    $path = parse_url($path);
    $coordinates = $path['host']; // Silly place to find it, but see
                                  // the note at the end of the section.
    if(strlen($coordinates)!=21) return false;
    if(strspn($coordinates, '0123456789')!=21) return false;
    list($northing, $easting, $radius)=sscanf($coordinates, '%07d%07d%07d');

    $full_image_size = ceil($radius*2*100/250);
    
    $full_image = imagecreate($full_image_size, $full_image_size);
    $black = imagecolorallocate($full_image, 0, 0, 0);
    // We use black as a background for unmapped regions.
    imagefill($full_image, 0, 0, $black);

    $maximum_northing = $northing+$radius;
    $minimum_northing = $northing-$radius;
    $maximum_easting = $easting+$radius;
    $minimum_easting = $easting-$radius;
    $bottommost_tile_northing = floor($minimum_northing/250)*250;
    $topmost_tile_northing = ceil($maximum_northing/250)*250;
    $leftmost_tile_easting = floor($minimum_easting/250)*250;
    $rightmost_tile_easting = ceil($maximum_easting/250)*250;

    for($tile_northing=$bottommost_tile_northing;
        $tile_northing<=$topmost_tile_northing;
        $tile_northing+=250)
    for($tile_easting=$leftmost_tile_easting;
        $tile_easting<=$rightmost_tile_easting;
        $tile_easting+=250)
    {
        $full_image_x = 100*($tile_easting-$minimum_easting)/250;
        $full_image_y = 100*($maximum_northing-$tile_northing)/250;
        $tile_name = sprintf('%07d%07d.png', $tile_northing, $tile_easting);
        if(!file_exists('tiles/'.$tile_name)) continue;
        $tile = imagecreatefrompng('tiles/'.$tile_name);
        imagecopy($full_image, $tile, $full_image_x, $full_image_y, 0, 0, 100, 
                  100);
        imagedestroy($tile);
    }
    ob_start();
    imagepng($full_image);
    imagedestroy($full_image);
    $this->png_data = ob_get_contents();
    ob_end_clean();
    $this->data_length = strlen($this->png_data);
    return true;
}

function stream_close()
{
    $this->png_data = null;
}

function stream_read($bytes)
{
    if(strlen($this->png_data)==0)
        return false;
    $return = substr($this->png_data, 0, $bytes);
    $this->png_data = substr($this->png_data, $bytes);
    return $return;
}

function stream_write(){}

function stream_eof()
{
    return $this->png_data == 0;
}

function stream_tell()
{
    return $this->data_length-strlen($this->png_data);
}

function stream_seek()
{
    return false;
}

function stream_flush()
{
    return false; // We don't store data, silly.
}

function stream_stat()
{
    return false;
}

}

// We put the stream wrapper registration here, with the wrapper it
// registers, to save the hassle of remembering to register it every
// time we include the file.
//
// This of course assumes that we're never tempted to use the same
// wrapper protocol (nzmg) for different types of stream.
stream_wrapper_register('nzmg', 'orthophoto_stream');
?>
