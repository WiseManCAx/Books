<?php

function is_a_square_number($n)
{
    // Fail values unsuitable for sqrt().
    if(!is_numeric($n))
        return false;
    if($n<0)
        return false;
    $square_root = sqrt($n);
    return ($square_root == intval($square_root));
}

$numbers = array(-1,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,'!');
$squares = array_filter($numbers, 'is_a_square_number');
// $squares now contains the array (0,1,4,9,16);

?>