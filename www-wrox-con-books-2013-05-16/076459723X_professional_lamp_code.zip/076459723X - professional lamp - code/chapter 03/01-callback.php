<?php

// Using an object’s method as a callback in array_map().
// Each element of $untidy_array is passed in turn to $parser->tidy(),
// and the returned values are stored in $tidied_array
$tidied_array = array_map(array($parser, 'tidy'), $untidy_array);

// Using a static class method as a callback in array_map().
// Each element of $untidy_array is passed in turn to Parser::tidy(),
// and the returned values are stored in $tidied_array
$tidied_array = array_map(array('Parser', 'tidy'), $untidy_array);
class Parser
{
// An example method that trims trailing whitespace and
// shell-style comments starting with '#' from a single
// line of text.
static function strip_comments($element)
{
    $element = preg_replace('/#[^#]*$/', '', $element);
    $element = rtrim($element);
    return $element;
}
}

$shell_script = file('foo.sh');
$tidied_script = array_map(array('Parser', 'strip_comments'), $shell_script);


// An object is able to use its own methods in array callbacks,
// both on arguments passed to it and on its own properties.
$tidied_code = array_map(array($this, 'tidy'), $this->code_array);

// Class methods are also accessible as callbacks within the class.
$tidied_code = array_map(array('self', 'tidy'), $code_array);

?>