<?php

function imagedatapoint($datapoint, $key, $image)
{
    $width = $height = $datapoint[2]*2;
    imageellipse($image, $datapoint[0], $datapoint[1], $width, $height, 
                 $datapoint[3]);
}

array_walk('imagedatapoint', $datapoints, $image);

?>