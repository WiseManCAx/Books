<?php

include_once('orthophoto_stream.php'); // the class has to be declared before
                                       // it can be used, of course.
function display_orthophoto($northing, $easting, $radius)
{
    $filename = sprintf('nzmg://%07d%07d%07d', $northing, $easting, $radius);

    // All the stream-based stuff happens here.
    $image = imagecreatefrompng($filename);

    // A bit of post-processing to raise this code above triviality.
    // Draw a circle of the specified radius (the image is a square, after
    // all), and place a cross at the centre.
    // We need to find the image's white value
    $white = imagecolorexact($image, 255, 255, 255);
    if($white==-1) // Okay, it's not already there.
        $white = imagecolorallocate($image, 255, 255, 255);
    // The circle is centered on the image, and is just large enough to
    // touch the sides.
    $imagesize = imagesx($image);
    $middle = $imagesize>>1;
    imageellipse($image, $middle, $middle, $imagesize, $imagesize, $white);
    imageline($image, $middle, $middle+5, $middle, $middle-5, $white);
    imageline($image, $middle+5, $middle, $middle-5, $middle, $white);
    imagestring($image, 0, 0, 0,
                'Sourced from Orthophoto R11 Auckland Crown Copyright Reserved.',
                $white);
    imagepng($image);
    imagedestroy($image);
}

?>