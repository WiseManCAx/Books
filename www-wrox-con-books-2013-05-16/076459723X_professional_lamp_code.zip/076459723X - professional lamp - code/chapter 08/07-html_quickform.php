<?php
require_once ("HTML/QuickForm.php");

//create a new form object
$form = new HTML_QuickForm('firstForm');

//add two input fields;  this is completely customizable
$form->addElement('text', 'name', 'Your full name:', array('size' => 50, 
'maxlength' => 255));
$form->addElement('text', 'email', 'Your email address:', array('size' => 50, 
'maxlength' => 255));

//add a submit button
$form->addElement('submit', null, 'Send');

//add validation rules of our choosing
//using addRule('field_to_be_validated', 'error_message to be displayed',
// 'validation_type', 
$form->addRule('name', 'Empty Name Field', 'required', null, 'client');
$form->addRule('email', 'Empty Email Address', 'required', null, 'client');
$form->addRule('email', 'Incorrect Format for Email Address', 'email', null, 
'client');

//check to make sure input followed all our rules
//if so, put all form elements into an array for us
//for sake of example, let's print the values
if ($form->validate()) {
    $elements=$form->exportValues();
    print_r ($elements);
    exit;
}

//show the form
$form->display();
?>
