<?php
require_once("Auth/HTTP.php");     

$a = new Auth_HTTP("DB", "mysqli://username:password@localhost/databasename");

$a->start();
?>
