<?php
require_once("date.php");

$currweek = new Date();

$weeksleft = 52 - ($currweek->getWeekofYear());

echo "There are " . $weeksleft . " weeks left in the year.";

?>
