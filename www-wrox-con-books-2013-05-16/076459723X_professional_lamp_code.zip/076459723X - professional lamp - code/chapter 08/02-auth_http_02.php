<?php

require_once("Auth/HTTP.php");

$AuthOptions = array(
//use the same data source name (database login info) as in previous example
'dsn'=>"mysqli://username:password@localhost/databasename",

//specify the database table that contains user info
'table'=>"users",

//specify the column that holds the username
'usernamecol'=>"username",

//specify the column that holds the passwords
'passwordcol'=>"password",

//specify the encryption type used
'cryptType'=>"md5",

);


$a = new Auth_HTTP("DB", $AuthOptions);

//specify the name of your realm
$a->setRealm('Registered Users Only');

//specify the error message seen by the user if authentication fails
$a->setCancelText('<h2>Access Denied.</h2>');

$a->start(); 

//check to see if the user is authorized
if($a->getAuth()) 
{
    //body of authorized text goes here.
    echo "Hi there, authorized user!";
   
};

?>
