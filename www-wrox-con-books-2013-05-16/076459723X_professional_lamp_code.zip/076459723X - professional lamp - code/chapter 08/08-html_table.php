<?php

require_once ("HTML/Table.php");


//set up attributes for our table, using common HTML attributes as
//array keys and their values as array values
$attributes = array("width" => "50%", "border" => "1");

//create a new table object
$table = new HTML_Table($attributes);

//configure table
//AutoGrow is for an unknown number of rows
//AutoFill inserts text for every empty cell
//Because we are pretending not to be sure how big our table will be, we 
//will set this option to true.
$table -> setAutoGrow(true);
$table -> setAutoFill("-");


//get some data for our table
$rows = array(
 '0' => array("Number One", "Number Two", "Number Three"),
 '1' => array("Numero Uno", "Numero Dos", "Numero Tres"),
);

//populate the table
for($nr = 0; $nr < count($rows); $nr++) {
 //the header row comes first
	$table -> setHeaderContents( $nr+1, 0, (string)$nr);
 for($i = 0; $i < 3; $i++) {
  if("" != $rows[$nr][$i])
 //the cell contents come next  
  $table -> setCellContents( $nr+1, $i+1, $rows[$nr][$i]);
 }
}

//set background for every other row
//skip the first row so we use a value of 1 to start
$altRow = array("bgcolor"=>"#FFFFCC");
$table -> altRowAttributes(1, null, $altRow);

//set header info for each cell of the table
//based on coordinates. 0,0 is top left cell.
//the third value is the contents to be shown
$table -> setHeaderContents(0, 0, " ");
$table -> setHeaderContents(0, 1, "Field 1");
$table -> setHeaderContents(0, 2, "Field 2");
$table -> setHeaderContents(0, 3, "Field 3");

//set attributes for the header rows and first column
//first row and column = 0.
$hrAttrs = array("bgcolor" => "#FFFF4D");
$table -> setRowAttributes(0, $hrAttrs, true);
$table -> setColAttributes(0, $hrAttrs);

//send it to the browser
echo $table->toHTML();


?>
