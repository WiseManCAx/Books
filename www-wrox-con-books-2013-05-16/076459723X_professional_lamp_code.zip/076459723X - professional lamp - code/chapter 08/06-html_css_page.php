<?php
require_once("HTML/CSS.php");
require_once("HTML/Page.php");


$css = new HTML_CSS();

//set the styles
  $css->setStyle('body', 'background-color', '#FF00CC');
  $css->setStyle('body', 'color', '#ffffff');
  $css->setStyle('h1', 'text-align', 'center');
  $css->setStyle('h1', 'font', '16pt erdana');
  $css->setStyle('p', 'font', '12pt verdana');

//create a new page
 $p = new HTML_Page();

 $p->setTitle("Testing the CSS");

 $p->addStyleDeclaration($css, 'text/css');
 $p->addBodyContent("<h1>Wow, this background is really bright</h1>");
 $p->addBodyContent("<p>This should wake you up.</p>");

 $p->display();
 ?>
