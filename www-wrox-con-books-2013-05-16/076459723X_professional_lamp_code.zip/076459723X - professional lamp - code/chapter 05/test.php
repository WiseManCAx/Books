<?php

// Check PHP environment
require_once 'class.ConfigManager.php';
$cfg = new ConfigManager('reqs.xml','xml');
$cfg->processConfig();

?>
