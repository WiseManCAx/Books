<?php

if (extension_loaded('mysql'))
{
  echo "MySQL is available.\n";
}
else
{
  echo "MySQL is NOT available.\n";
}

if (extension_loaded('fakesql'))
{
  echo "Fake SQL is available.\n";
}
else
{
  echo "Fake SQL is NOT available.\n";
}

?>
