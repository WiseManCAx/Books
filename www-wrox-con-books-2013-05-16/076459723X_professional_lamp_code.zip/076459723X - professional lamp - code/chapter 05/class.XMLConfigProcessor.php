<?php

require_once 'interface.ConfigProcessor.php';

class XMLConfigProcessor implements ConfigProcessor
{

    public  $xmlfile;
    private $message = '';
    private $xml;


    public function __construct($xmlfile = null)
    {
        if ($xmlfile)
        {
            $this->xmlfile = $xmlfile;
        }
    }

    public function process()
    {
        // Check for needed libraries
        if (!$this->checkDeps() or 
            !$this->checkConfigAccess())
        {
            return $this->message;
        }
        
        $this->xml = simplexml_load_file($this->xmlfile);
                        
        if (!$this->checkPHP() or
            !$this->checkExtensions() or
            !$this->checkConfig())
        {
            return $this->message;
        }
    }

    private function checkConfigAccess()
    {
        $returnValue = false;
        
        // Check to see if config file exists and is readable
        if (file_exists($this->xmlfile) and 
            is_readable($this->xmlfile))
        {
            $returnValue = true;
        }
        else
        {
            $this->message .= "Warning: " .
                              "Could not access config file.\n";
        }
        
        // Clear cached filesystem lookups
        clearstatcache();
        
        return $returnValue;
    }

    private function checkDeps()
    {
        $returnValue = true;
        
        // Check for SimpleXML
        if (!extension_loaded('SimpleXML'))
        {
            $returnValue = false;
            $this->message .= "Warning: " .
                              "SimpleXML extension not available.\n";
        }
        
        return $returnValue;
    }
    
    public function checkExtensions()
    {
        $returnValue = true;
        
        // Check for all listed extensions
        $exts = $this->xml->xpath('packages/package');
        foreach ($exts as $ext)
        {
            if (!extension_loaded($ext['name']))
            {
                $returnValue = false;
                $this->message .= "Warning: " .
                                  $ext['name'] . 
                                  " extension not available.\n";
            }
        }
        
        return $returnValue;
    }
    
    public function checkPHP()
    {
        // Check if PHP requirement is present
        if (count($phpreq = $this->xml->xpath('environment/php')) == 0)
        {
            return true;
        }
        
        // Flatten element array
        $phpreq = $phpreq[0];
        
        // Check minimum version
        if ($phpreq['minversion'] and
            version_compare(phpversion(), 
                        $phpreq['minversion']) < 0)
        {
            $this->message .= "Warning: " .
                              "PHP version is less than " . 
                              $phpreq['minversion'] . ".\n";
            return false;
        }
        
        // Check maximum version
        if ($phpreq['maxversion'] and
            version_compare(phpversion(), 
                        $phpreq['maxversion']) > 0)
        {
            $this->message .= "Warning: " .
                              "PHP version is greater than " .
                              $phpreq['maxversion'] . ".\n";
            return false;
        }
        
        return true;
    }
    
    public function checkConfig()
    {
        $returnValue = true;
        
        // Get all config values
        $cfg = ini_get_all();

        // Cycle through setting elements
        $settings = $this->xml->xpath('environment/setting');
        foreach ($settings as $setting)
        {
            $value = $setting['value'];
            // Convert boolean values to ini_get() values
            switch (strtolower($value))
            {
                case 'off':
                case '0':
                case 'false':
                case 'no':
                    $value = '';
                    break;
                case 'on':
                case 'true':
                case 'yes':
                    $value = '1';
                    break;
            }
            
            // Flatten name
            $name = (string) $setting['name'];
            
            // Check config value, set if needed
            if (!array_key_exists($name, $cfg) or
                ($value != 
                 $cfg[$name]['local_value'] and
                 ini_set($name, $setting['value']) === false))
            {
                $returnValue = false;
                $this->message .= "Warning: " .
                                  $name . 
                                  " not set to the required value of: "
                                  . $setting['value'] . ".\n";
            }
        }
        
        return $returnValue;
    }
}

?>
