<?php

print_r(get_extension_funcs('simplexml'));

?>
