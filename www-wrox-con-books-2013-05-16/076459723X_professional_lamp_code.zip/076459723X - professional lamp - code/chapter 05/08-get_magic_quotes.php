<?php

echo "Magic quotes GPC: " . get_magic_quotes_gpc() . "\n" .
     "Magic quotes runtime: " . get_magic_quotes_runtime() . "\n";

?>
