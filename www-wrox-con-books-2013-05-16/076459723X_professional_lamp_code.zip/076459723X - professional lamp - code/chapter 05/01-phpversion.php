<?php

echo "The current version of PHP installed is: " . phpversion();

?>
