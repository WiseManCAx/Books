<?php

print_r(ini_get_all());

?>
