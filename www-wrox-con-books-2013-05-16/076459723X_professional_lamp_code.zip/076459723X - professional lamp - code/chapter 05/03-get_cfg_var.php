<?php

echo "Error reporting: " . get_cfg_var('error_reporting') . "\n" .
     "Register globals: " . get_cfg_var('register_globals') . "\n" .
     "Nonexistant setting: " . get_cfg_var('nonexistant') . "\n";

?>
