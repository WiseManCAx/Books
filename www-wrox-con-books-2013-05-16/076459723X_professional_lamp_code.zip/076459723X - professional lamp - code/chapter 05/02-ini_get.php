<?php

echo "Error reporting: " . ini_get('error_reporting') . "\n" .
     "Register globals: " . ini_get('register_globals') . "\n" .
     "Nonexistant setting: " . ini_get('nonexistant') . "\n";

?>
