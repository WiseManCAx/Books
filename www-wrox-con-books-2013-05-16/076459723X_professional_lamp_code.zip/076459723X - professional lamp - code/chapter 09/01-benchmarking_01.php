<?php
$variable = 'string';

$start = microtime(true);
for($i=0; $i<1000000; ++$i)
{
    $string = "this string has a $variable embedded into it";
}
$laptime = microtime(true);
for($i=0; $i<1000000; ++$i)
{
    $string = "this string has a ".$variable." inserted into it";
}
$finish = microtime(true);

echo "Variable interpolation required ",$laptime-$start," seconds for one million 
iterations.\n";
echo "Variable concatenation required ",$finish-$laptime," seconds for one million 
iterations.\n";
?>
