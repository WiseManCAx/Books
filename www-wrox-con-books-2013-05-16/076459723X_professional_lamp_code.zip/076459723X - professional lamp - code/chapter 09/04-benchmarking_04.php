<?php
require 'Benchmark/Timer.php';

$variable = 'string';

$timer = new Benchmark_Timer();

$timer->start();
for($i=0; $i<1000000; ++$i)
{
    $string = "this string has a $variable embedded into it";
}
$timer->setMarker('laptime');
for($i=0; $i<1000000; ++$i)
{
    $string = "this string has a ".$variable." inserted into it";
}
$timer->setMarker('finish');

echo "Variable interpolation required ",$timer->timeElapsed('Start','laptime')," 
seconds for one million iterations.\n";
echo "Variable concatenation required ",$timer->timeElapsed('laptime','finish')," 
seconds for one million iterations.\n";

$timer->stop();
$timer->display();
?>
