<?php
function generate_test($string)
{
    $code = '<?php
$interpolated="badgers!";

for($i=0; $i<100; ++$i)
    $gstring = "'.$string.'";
?>';
    $temp_file = tempnam('.','_runtest');
    $fp = fopen($temp_file,'wb');
    fwrite($fp, $code);
    fclose($fp);
    return $temp_file;
}

function run($file)
{
    $average_runtime = 0;
    for($runs=0; $runs<5; ++$runs)
    {
        $start = microtime(true);
        shell_exec("php -f $file"); // If necessary, supply path information here
        $end = microtime(true);
        $average_runtime += $end-$start;
    }
    return $average_runtime/5;
}

$log = fopen('logfile.txt','wb');
for($string_size=1<<6; $string_size<=26176; $string_size+=1<<9)
{
    $generic_string = str_repeat("wibble splunge!\n", $string_size);
    $real_string_size = 16*$string_size;
    $all_positions = range(0,$real_string_size-1);
    for($num_variable_interpolations=0; $num_variable_interpolations<100; 
        ++$num_variable_interpolations)
    {
        echo $string_size,"\t",$num_variable_interpolations,"\n";
        $string = $generic_string;
        if($num_variable_interpolations==0)
            $positions = array();
        else
            $positions = array_rand($all_positions,$num_variable_interpolations);
        if(count($positions)==1) $positions = array($positions);
        foreach($positions as $position)
        {
            $string = substr($string,0,$position).'$'.substr($string,$position);
        }
        $string = str_replace('$','{$interpolated}', $string);
//        $string = str_replace('$','".$interpolated."', $string);
        $file = generate_test($string);
        $runtime = run($file);
        unlink($file);
        fwrite($log, 
               $string_size."\t".$num_variable_interpolations."\t".$runtime."\n");
    }
}
fclose($log);
?>
