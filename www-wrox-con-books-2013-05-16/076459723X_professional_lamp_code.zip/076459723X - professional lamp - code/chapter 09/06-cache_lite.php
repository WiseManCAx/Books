<?php
require_once 'Cache/Lite.php';

$id = '42'; // This is used to identify which cache file to use;
            // anything unique that can be remembered from access to
            // access will do; if you're caching an entire page this way
            // its URL is a natural choice.

$options = array(
    'cacheDir' => '/cachefiles/', // Cache_Lite only does file storage:
                                  // you'll need to specify an
                                  //appropriate directory here.
    'lifeTime' => 3600            // We'll force an update every hour.
);

$Cache_Lite = new Cache_Lite($options);

if ($data = $Cache_Lite->get($id)) {

    // A cached copy has been found

} else {

    // No copy in the cache; generate its contents
    // and store in $data.
    $data = "Hello, World!"; // This could just as easily be an entire page.

    // When that's done, save it in the cache.
    $Cache_Lite->save($data);
}
// Either way, the output of the page is in $data. I presume someone wants
// to see it...
echo $data;
?>
