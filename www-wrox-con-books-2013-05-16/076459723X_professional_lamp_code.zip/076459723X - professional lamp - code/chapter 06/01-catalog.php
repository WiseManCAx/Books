<?php
$category = '';
$item = '';
if (isset($_GET['cat']))
{
  $category = $_GET['cat'];
}
if (isset($_GET['item']))
{
  $item = $_GET['item'];
}
echo "Category: " . $category . "<br />\n" .
     "Item: " . $item . "<br />\n";
?>
