<?php

class WebImage
{
  public $gdresource;
  public $type;

  // Release resources
  public function __destruct()
  {
    if ($this->gdresource)
    {
      imagedestroy($this->gdresource);
    }
  }


  // Load an image from a file
  public function load($file)
  {
    // Get image mimetype
    $size = getimagesize($file);
    $this->type = $size['mime'];

    // Load image based on type
    switch ($this->type)
    {
      case 'image/jpeg':
        $this->gdresource = imagecreatefromjpeg($file);
        break;
      case 'image/png':
        $this->gdresource = imagecreatefrompng($file);
        break;
      case 'image/gif':
        $this->gdresource = imagecreatefromgif($file);
        break;
    }

    // Retain the alpha information
    imagesavealpha($this->gdresource, true);
  }


  // Save the file to the local filesystem
  public function save($file)
  {
    switch ($this->type)
    {
      case 'image/jpeg':
        imagejpeg($this->gdresource, $file);
        break;
      case 'image/png':
        imagepng($this->gdresource, $file);
        break;
      case 'image/gif':
        // Convert back to palette
        if (imageistruecolor($this->gdresource))
        {
          imagetruecolortopalette($this->gdresource, false, 256);
        }
        imagegif($this->gdresource, $file);
        break;
    }
  }


  // Display the image in the browser
  public function display()
  {
    switch ($this->type)
    {
      case 'image/jpeg':
        header("Content-type: image/jpeg");
        imagejpeg($this->gdresource);
        break;
      case 'image/png':
        header("Content-type: image/png");
        imagepng($this->gdresource);
        break;
      case 'image/gif':
        // Convert back to palette
        if (imageistruecolor($this->gdresource))
        {
          imagetruecolortopalette($this->gdresource, false, 256);
        }
        header("Content-type: image/gif");
        imagegif($this->gdresource);
        break;
    }
  }

}

  // Resize the image
  public function resize()
  {
    require_once 'class.ImageResize.php';

    $ir = new ImageResize();

    // Set resize parameters based on arguments
    switch (func_num_args())
    {
      case 1:
        $ir->ratio = func_get_arg(0);
        break;
      case 2:
        $ir->max_width = func_get_arg(0);
        $ir->max_height = func_get_arg(1);
        break;
    }

    // Perform the resize
    $this->gdresource = $ir->process($this->gdresource);
  }

  // Rotate the image
  public function rotate($degrees)
  {
    require_once 'class.ImageRotate.php';

    $ir = new ImageRotate();
        
    // Set rotate parameters
    $ir->rotation = $degrees;
        
    // Perform the rotation
    $this->gdresource = $ir->process($this->gdresource);
  }

  // Add a caption to the image
  public function caption($text, 
                          $font, 
                          $size = null, 
                          $padding = null, 
                          $drawline = null)
  {
    require_once 'class.ImageCaption.php';

    $ic = new ImageCaption();
        
    // Set size, padding, line if needed
    if ($size)
    {
      $ic->fontsize = $size;
    }
    if ($padding !== null)
    {
      $ic->padding = $padding;
    }
    if ($drawline !== null)
    {
      $ic->drawline = $drawline;
    }
        
    // Set font, caption
    $ic->fontfile = $font;
    $ic->caption = $text;
        
    // Perform the captioning
    $this->gdresource = $ic->process($this->gdresource);
  }

  public function logo($logofile,
                       $loc_x = null,
                       $loc_y = null,
                       $padding = null,
                       $ratio = null)
  {
    require_once 'class.ImageLogo.php';

    $il = new ImageLogo();

    // Set logo file
    $il->logofile = $logofile;
    
    // Set location, padding, and ratio if needed
    if ($loc_x !== null)
    {
      $il->location['x'] = $loc_x;
    }
    if ($loc_y !== null)
    {
      $il->location['y'] = $loc_y;
    }
    if ($padding !== null)
    {
      $il->padding = $padding;
    }
    if ($ratio !== null)
    {
      $il->ratio = $ratio;
    }

    // Perform the logo placement
    $this->gdresource = $il->process($this->gdresource);
  }

?>
