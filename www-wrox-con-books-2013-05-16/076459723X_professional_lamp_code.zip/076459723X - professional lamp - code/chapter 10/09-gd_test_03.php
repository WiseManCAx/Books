<?php

require_once 'class.WebImage.php';

$img = new WebImage();
$img->load('base.png');
$img->rotate(180);
$img->display();

?>
