<?php
header('Content-type: application/x-shockwave-flash');
$a= new SWFmovie();
$a->setDimension(100,100); //width and length in that order
$a->setBackground(0,0,255); // red, green, and blue integers
$a->output();
?>
