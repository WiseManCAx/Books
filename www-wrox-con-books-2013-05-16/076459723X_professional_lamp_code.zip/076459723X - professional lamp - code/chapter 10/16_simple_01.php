<?php
if (file_exists('beachfront.xml')) {
   $data = simplexml_load_file('beachfront.xml');

   print_r($data);
}
?>
