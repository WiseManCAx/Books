<?php
//create a movie object
$aMovie = new SWFMovie();
//set the background to white
$aMovie->setBackground(255, 255, 255);

//images to display 
$images = array("1.jpg", "2.jpg", "3.jpg");
  
$bitmapImage = new SWFBitmap(fOpen($images[1], "rb"));
$w = $bitmapImage->getWidth();
$h = $bitmapImage->getHeight();

//create a sprite which will act as a mini movie
$sprite = new SWFSprite();
//add stop action to the first frame
$sprite->add(new SWFAction("stop();"));
   
//set the size of the movie with extra psce for buttons
$aMovie->setDimension((1*$w),(1.5* $h)+3);

//loop through all of the images
for($i=0; $i<count($images);$i++){

//create a bitmap from an image
$bitmapImage = new SWFBitmap(fopen($images[$i], "rb"));

//create a shape object to hold the image
$shape = new SWFShape();
//generate the fill for the shape of the image
$fill = $shape->addFill($bitmapImage);
//add the fill to the shape
$shape->setRightFill($fill);

//draw a line around the shape to set the size
$shape->drawLine($w, 0);
$shape->drawLine(0, $h);
$shape->drawLine(-$w, 0);
$shape->drawLine(0, -$h);
//add the shape to the sprite so that it is displayed
$sprite->add($shape);
//generate a new frame and go to it
$sprite->nextFrame();
}

//goto frame 0
$sprite->add(new SWFAction("gotoFrame(0);"));
//again generate a new frame
$sprite->nextFrame();

//add the sprite and get its handler
$handler = $aMovie->add($sprite);
//we can name the sprite now with the handler
 $handler->setName("images");
//we can move the sprite also with the handler
$handler->moveTo(0,2);

//create a shape again
$shape = new SWFShape();
//create another bitmap this time for a button image
$bitmapImage = new SWFBitmap(fopen("button.jpg", "rb"));
$file = $shape->addFill($bitmapImage);
$shape->setRightFill($fill);
//create the border around the shape
$shape->drawLine($w, 0);
$shape->drawLine(0, $h);
$shape->drawLine(-$w, 0);
$shape->drawLine(0, -$h);

//now actually create a button object
$button = new SWFButton();
//add the shape to the button with all of its default flags which are
//all actually predefined integer values
$button->addShape($shape, SWFBUTTON_HIT | 
SWFBUTTON_UP | SWFBUTTON_DOWN |
SWFBUTTON_OVER);
//add an action to go to the next frame
//on the sprite.  The sprite is referenced by “/images”
$button->addAction(new SWFAction("setTarget('/images');
nextFrame();"),SWFBUTTON_MOUSEDOWN);

//add the button to the move and save the returned handler
$handler = $aMovie->add($button);
//use the handler to move the button below the images
$handler->moveTo(0,$h+3);
$aMovie->nextFrame();
//send the appropriate header to the browser
header("Content-Type:application/x-shockwave-flash");
//output the movie to the browser
$aMovie->output();
?>
