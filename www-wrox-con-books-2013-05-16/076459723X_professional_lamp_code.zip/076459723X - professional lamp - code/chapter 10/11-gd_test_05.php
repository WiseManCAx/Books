<?php

require_once 'class.WebImage.php';

$img = new WebImage();
$img->load('base.png');
$img->caption('An example of plantlife found on Maui.',
              'FUJIWIDR.TTF',
              13,
              5,
              true);
$img->logo('logo.png', 'r', 'b', 5, 0.3);
$img->display();

?>
