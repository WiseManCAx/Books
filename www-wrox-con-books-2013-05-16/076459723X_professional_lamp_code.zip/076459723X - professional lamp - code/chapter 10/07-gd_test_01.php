<?php

require_once 'class.WebImage.php';

$img = new WebImage();
$img->load('base.png');
$img->display();

?>
