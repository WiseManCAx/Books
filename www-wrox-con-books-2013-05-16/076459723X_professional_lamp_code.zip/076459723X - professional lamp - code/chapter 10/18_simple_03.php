<?php
if (file_exists('beachfront.xml')) {
   $data = simplexml_load_file('beachfront.xml');


//find and list all the "locations" in our XML file
//"locations" are under "descriptions" which are under "rentals"
$find = $data->xpath('/rentals/description/location');

while (list(, $v) = each($find)) {
   echo $v. "\n";
   }
}
?>
