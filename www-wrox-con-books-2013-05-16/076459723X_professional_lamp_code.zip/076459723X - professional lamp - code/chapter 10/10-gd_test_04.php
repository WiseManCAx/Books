<?php

require_once 'class.WebImage.php';

$img = new WebImage();
$img->load('base.png');
$img->caption('An example of plantlife found on Maui.',
              'FUJIWIDR.TTF',
              15,
              5,
              true);
$img->display();

?>
