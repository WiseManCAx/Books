<?php
if (file_exists('beachfront.xml')) {
   $data = simplexml_load_file('beachfront.xml');

foreach($data as $main) {
   echo "<hr>";
   foreach ($main as $k => $v) {
   echo $k . ": " . $v . "<br \>";
   }
}

}
?>
