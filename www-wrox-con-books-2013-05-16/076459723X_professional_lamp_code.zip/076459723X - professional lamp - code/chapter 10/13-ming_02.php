<?php
header('Content-type: application/x-shockwave-flash');
$a= new SWFMovie();
$a->setDimension(100,100); //width and length in that order
$a->setBackground(0,0,255); // red, green, and blue integers

$s =new SWFShape();  //generate a shape object
$s->setLine(4, 30, 60, 100); //set the line width to 4 along
// with red, green, and blue integer values
$s->setLeftFill($s->addFill(300, 200, 100));
   //set the color of the shape with red, green
// and integer values
$s->movePenTo(20, 20);
//move our imaginary pen to a new location
$s->drawLineTo(20, 80);
   //draw lines to a new set of points
$s->drawLineTo(80, 80);
$s->drawlineTo(80,20);
$s->drawLineTo(20,20);
$a->add($s);  //add the shape to the movie
      
$a->nextFrame();  //advance a frame in the movie
$a->output();   //output everything to the browser
?>
