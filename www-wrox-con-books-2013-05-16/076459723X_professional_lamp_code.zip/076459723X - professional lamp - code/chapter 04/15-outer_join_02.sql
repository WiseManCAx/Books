SELECT ma.make_name, mo.model_name, n.color, n.modelyear FROM New_Vehicles n LEFT 
OUTER JOIN Models mo USING (model_id) LEFT OUTER JOIN Makes ma USING (make_id);
