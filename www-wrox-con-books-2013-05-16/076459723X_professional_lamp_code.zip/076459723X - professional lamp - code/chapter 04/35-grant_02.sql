GRANT SELECT, INSERT, UPDATE, DELETE ON VehicleInventory.New_Vehicles TO 
testuser2@localhost IDENTIFIED BY 'testpass2';
