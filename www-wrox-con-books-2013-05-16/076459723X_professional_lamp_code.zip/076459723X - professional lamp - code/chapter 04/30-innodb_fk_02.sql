ALTER TABLE Models ENGINE=InnoDB;
ALTER TABLE New_Vehicles ADD CONSTRAINT refmdl FOREIGN KEY (model_id) REFERENCES 
Models (model_id);
