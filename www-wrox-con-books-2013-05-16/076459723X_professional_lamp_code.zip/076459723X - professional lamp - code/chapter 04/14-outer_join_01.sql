SELECT mo.model_name, n.color, n.modelyear FROM New_Vehicles n LEFT OUTER JOIN 
Models mo USING (model_id);
