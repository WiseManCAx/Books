INSERT INTO mysql.db (Host, Db, User, Select_priv, Insert_priv, Update_priv, 
Delete_priv) VALUES ('localhost', 'VehicleInventory', 'testuser6', 'Y', 'Y', 'Y', 
'Y');
