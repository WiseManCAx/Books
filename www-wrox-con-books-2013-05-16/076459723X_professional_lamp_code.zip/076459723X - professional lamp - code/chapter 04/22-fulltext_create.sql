CREATE TABLE testft (testint int, testvc varchar(50), testtxt text, FULLTEXT 
(testvc, testtxt) );
