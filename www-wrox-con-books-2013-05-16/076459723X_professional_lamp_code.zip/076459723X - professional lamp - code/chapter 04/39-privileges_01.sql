INSERT INTO mysql.user (Host, User, Password) VALUES ('localhost', 'testuser6', 
PASSWORD('testpass6') );
