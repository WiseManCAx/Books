SELECT model_id, model_name, color, modelyear FROM Models INNER JOIN New_Vehicles 
ON Models.model_id = New_Vehicles.model_id;
