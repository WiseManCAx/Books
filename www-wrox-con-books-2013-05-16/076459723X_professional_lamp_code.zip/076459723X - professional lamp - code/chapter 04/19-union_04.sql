(SELECT color, modelyear, model_id FROM New_Vehicles) UNION (SELECT color, 
modelyear, model_id FROM Used_Vehicles) LEFT OUTER JOIN Models USING (model_id) 
LEFT OUTER JOIN Makes USING (make_id);
