SELECT m.model_name, n.color, n.modelyear FROM Models m INNER JOIN New_Vehicles n 
USING (model_id);
