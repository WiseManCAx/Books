GRANT SELECT (color) ON VehicleInventory.New_Vehicles TO testuser3@localhost 
IDENTIFIED BY 'testpass3';
