SELECT vehicle_id, description FROM New_Vehicles WHERE MATCH (description) AGAINST 
('options');
