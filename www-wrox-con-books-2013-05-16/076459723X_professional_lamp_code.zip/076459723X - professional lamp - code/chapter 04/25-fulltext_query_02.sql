SELECT MATCH (description) AGAINST('options') AS relevance, description FROM 
New_Vehicles WHERE MATCH (description) AGAINST ('options') ORDER BY MATCH 
(description) AGAINST('options') \G
