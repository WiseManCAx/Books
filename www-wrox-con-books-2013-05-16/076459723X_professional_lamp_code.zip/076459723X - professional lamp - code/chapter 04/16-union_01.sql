(SELECT color, modelyear, model_id FROM New_Vehicles) UNION (SELECT color, 
modelyear, model_id FROM Used_Vehicles);
