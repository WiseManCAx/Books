SELECT ma.make_name, mo.model_name, n.color, n.modelyear FROM Makes ma, Models mo, 
New_Vehicles n WHERE ma.make_id = mo.make_id AND mo.model_id = n.model_id;
