ALTER TABLE New_Vehicles DROP INDEX description;
ALTER TABLE New_Vehicles ENGINE=InnoDB;