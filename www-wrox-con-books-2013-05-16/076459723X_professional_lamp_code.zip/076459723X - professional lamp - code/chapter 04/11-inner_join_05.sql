SELECT ma.make_name, mo.model_name, n.color, n.modelyear FROM Makes ma INNER JOIN 
Models mo USING (make_id) INNER JOIN New_Vehicles n USING (model_id);
