UPDATE Models SET model_id=123 WHERE model_id=1;
SELECT * FROM New_Vehicles \G
