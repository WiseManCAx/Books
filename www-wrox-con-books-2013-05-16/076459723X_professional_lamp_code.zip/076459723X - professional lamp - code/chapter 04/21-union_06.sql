(SELECT ma.make_name, mo.model_name, n.color, n.modelyear, n.price, n.description, 
NULL, 1 FROM New_Vehicles n LEFT OUTER JOIN Models mo USING (model_id) LEFT OUTER 
JOIN Makes ma USING (make_id)) UNION (SELECT ma.make_name, mo.model_name, u.color, 
u.modelyear, u.price, u.description, u.certified, u.warranty FROM Used_Vehicles u 
LEFT OUTER JOIN Models mo USING (model_id) LEFT OUTER JOIN Makes ma USING 
(make_id)) \G
