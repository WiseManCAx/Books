SELECT Models.model_name, New_Vehicles.color, New_Vehicles.modelyear FROM Models 
INNER JOIN New_Vehicles ON Models.model_id = New_Vehicles.model_id;
