<?php

class Circle
{
  public static function calcArea($r)
  {
    return pi() * pow($r, 2);
  }
}

$r = 5;
echo "Given a radius of " . $r .
     ", a circle has the area " . Circle::calcArea($r);

?>
