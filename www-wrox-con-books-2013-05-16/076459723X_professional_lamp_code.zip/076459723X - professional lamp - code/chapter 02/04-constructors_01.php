<?php

class Circle
{
  public function __construct()
  {
    // Perform actions when object is created
    echo "A circle object is being created.\n";
  }
}

$c = new Circle();

?>
