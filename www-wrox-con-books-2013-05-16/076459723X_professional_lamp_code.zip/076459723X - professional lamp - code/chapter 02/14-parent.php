<?php

class Shape
{
  public function draw()
  {
    echo "Shape::draw() has been called.\n";
  }
}

class Circle extends Shape
{
  public function draw()
  {
    echo "Circle::draw() has been called.\n";
    parent::draw();
  }
}


$c = new Circle();
$c->draw();

?>
