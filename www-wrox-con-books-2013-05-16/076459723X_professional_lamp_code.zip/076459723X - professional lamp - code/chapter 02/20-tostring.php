<?php

class Circle
{
  public function __toString()
  {
    return "Automatic string value for Circle";
  }
}

$c = new Circle();
echo "The value of \$c is: ";
echo $c;

?>
