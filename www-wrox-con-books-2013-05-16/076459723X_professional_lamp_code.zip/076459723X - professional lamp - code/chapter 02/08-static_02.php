<?php

class Circle
{
  private static $radius;

  public static function setRadius($r)
  {
    self::$radius = $r;
  }

  public static function getRadius()
  {
    return self::$radius;
  }
}

Circle::setRadius(5);
echo "Our statically accessed circle has a radius of " . 
     Circle::getRadius() . ".\n";

?>
