<?php

class Shape
{
  final public $origin = array('x'=>0, 'y'=>0);
}

class Circle extends Shape
{
  public $origin = 'This is invalid.';
}

$c = new Circle();

?>
