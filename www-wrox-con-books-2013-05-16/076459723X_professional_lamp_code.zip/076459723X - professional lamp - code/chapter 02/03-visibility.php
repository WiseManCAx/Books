<?php

class Circle
{
  private $center = array('x' => 0, 'y' => 0);
  private $radius = 1;

  public function setRadius($radius)
  {
    $this->radius = $radius;
  }
  public function setCenter($x, $y)
  {
    $this->center['x'] = $x;
    $this->center['y'] = $y;
  }
  public function calcArea()
  {
    return pi() * pow($this->radius, 2);
  }
}

$c = new Circle();
$c->setCenter(0,0);
$c->setRadius(10);

echo "The area of the circle is " . $c->calcArea() . "\n";

// Attempt to access a private property
echo "The private value of radius is " . $c->radius;

?>
