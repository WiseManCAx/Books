<?php

class Circle
{
  const pi = 3.14159265359;

  public function getPi()
  {
    return self::pi;
  }
}

echo "The value of Pi in our Circle class is " . Circle::pi . "\n";

$c = new Circle();
echo "To recap, the value of Pi in our Circle class is " . $c->getPi()

?>
