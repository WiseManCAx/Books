<?php
session_start();

class Circle
{
  public $radius;

  public $origin = array('x'=>0, 'y'=>0);
  
  public function __sleep()
  {
    echo 'zzzzz';
    
    return array('radius','origin');
  }
  
  public function __wakeup()
  {
    echo 'good morning!';
  }
}

echo 'Rise and shine.....';

$c = unserialize($_SESSION['c']);

echo '<br />The contents of our Circle object are:<br />';
echo 'Radius: ' . $c->radius . '<br />';
echo 'Origin: (' . $c->origin['x'] . ',' . $c->origin['y'] . ')';

?>
