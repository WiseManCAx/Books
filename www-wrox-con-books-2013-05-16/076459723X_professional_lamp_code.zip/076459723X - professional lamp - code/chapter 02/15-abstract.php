<?php

abstract class Shape
{
  public $origin = array('x'=>0, 'y'=>0);
}

class Circle extends Shape
{
  // Circle implementation
}


$c = new Circle();
print_r($c->origin);

$s = new Shape();
print_r($s->origin);

?>
