<?php

class Shape
{
  public $origin = array('x'=>0, 'y'=>0);
}

class Circle extends Shape
{
  public $radius;
}


$c = new Circle();
print_r($c->origin);

?>
