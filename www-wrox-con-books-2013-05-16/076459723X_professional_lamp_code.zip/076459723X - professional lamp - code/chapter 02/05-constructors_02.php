<?php

class Circle
{
  public $radius;

  public function __construct($r)
  {
    // Perform actions when object is created
    echo "A circle object is being created.\n";

    $this->radius = $r;
  }
}

$c = new Circle(10);

?>
