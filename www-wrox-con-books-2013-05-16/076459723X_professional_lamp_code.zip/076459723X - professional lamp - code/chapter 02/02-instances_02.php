<?php

class Circle
{
  public $radius;

  public function calcArea()
  {
    return pi() * pow($this->radius,  2);
  }
}

// Create a new instance of Circle
$c = new Circle();

// Change a property
$c->radius = 5;

// Use a method
echo 'The area of the circle is ' . $c->calcArea();

?>
