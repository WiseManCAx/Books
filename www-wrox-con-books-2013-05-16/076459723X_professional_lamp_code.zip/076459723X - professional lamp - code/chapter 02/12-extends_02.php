<?php

class Shape
{
  public $origin = array('x'=>0, 'y'=>0);
  public function getOrigin()
  {
    return $this->origin;
  }
}

class Circle extends Shape
{
  public function getOrigin()
  {
    return array('x'=>1, 'y'=>1);
  }
}


$c = new Circle();
print_r($c->getOrigin());

?>
