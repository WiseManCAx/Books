<?php
session_start();

class Circle
{
  public $radius;

  public $origin = array('x'=>0, 'y'=>0);
  
  public function __sleep()
  {
    echo 'zzzzz';
    
    return array('radius','origin');
  }
  
  public function __wakeup()
  {
    echo 'good morning!';
  }
}

$c = new Circle();
$c->radius = 5;
$c->origin['x'] = 3;
$c->origin['y'] = 4;

echo 'Preparing to sleep.....';

$_SESSION['c'] = serialize($c);

echo '<br /><a href="page2.php">Wake the object</a>';

?>
