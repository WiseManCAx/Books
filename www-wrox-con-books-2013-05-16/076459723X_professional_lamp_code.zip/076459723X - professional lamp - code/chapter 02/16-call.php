<?php

class Circle
{
  public function __call($m, $a)
  {
    echo "The method " . $m . " was called.\n" .
         "The arguments were as follows:\n";
    print_r($a);
  }
}


$c = new Circle();
$c->undefinedmethod(1, 'a', 2, 'b');

?>
