<?php

class Circle
{
  public function __construct()
  {
    // Perform actions when object is created
    echo "A circle object is being created.\n";
  }

  public function __destruct()
  {
    // Perform actions when object is destroyed
    echo "A circle object is being destroyed.\n";
  }
}

$c = new Circle();

// Destroy the circle object
unset($c);

?>
