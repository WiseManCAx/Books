<?php

class Circle
{
  public function __get($p)
  {
    return $this->$p;
  }
  
  public function __set($p, $v)
  {
    $this->$p = $v;
  }
}


$c = new Circle();
$c->nonexistent = 5;
echo "The value of our nonexistent property: " . $c->nonexistent;

?>
