function processResponse(oXML) {
   // exit if xml is undefined or 
   // doesn't have a documentElement
   if (!oXML) return;
   if (!oXML.documentElement) return;
   var doc = oXML.documentElement;
   // return a nodeList of all elements 
   // named username
   var unames = doc.getElementsByTagName('username');
   var msgs = new Array();
   // iterate through the username nodeList
   for (var i=0; i<unames.length; i++) {
      var u = unames.item(i);
      var username = u.getAttribute('value');
      var availability = u.getAttribute('available');
      // make the available attribute
      // more user-friendly
      if (availability == 'true') {
         availability = 'available';
      }
      else {
         availability = 'not available';
      }
      msgs[msgs.length] = 'Username '+ username 
         +' is '+ availability;
   }
   // create an unordered list element
   ul = document.createElement('ul');
   ul.id = 'msg';
   // for each message, create a list item
   // element and a text node containing 
   // the message. The text node is a child
   // node of the list item element, and the
   // the list item is a child node of the 
   // unordered list element.
   for (var k=0; k<msgs.length; k++) {
      var li = document.createElement('li');
      var txt = document.createTextNode(msgs[k]);
      li.appendChild(txt);
      ul.appendChild(li);
   }
   // obtain a reference to the maindiv element
   // and insert our new unordered list just before it
   var maindiv = document.getElementById('maindiv');
   maindiv.parentNode.insertBefore(ul,maindiv);
}
