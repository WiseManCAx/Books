function handleReadyStateChange() {
   if (!request) return;
   // ignore unless complete readyState
   if (request.readyState == 4) {
      // Ignore unless successful.
      // You might choose to handle errors
      // rather than ignore them.
      if (request.status == 200) {
         // act on the response
         var xmlbody = request.responseXML;
         request = false;
         processResponse(xmlbody);
      }
    }
}
