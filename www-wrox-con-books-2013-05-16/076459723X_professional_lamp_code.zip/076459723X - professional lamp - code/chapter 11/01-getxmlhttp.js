function getXMLHTTP() {
   var req = false;
   // first, try to instantiate the native object
   if(window.XMLHttpRequest) {
      try {
         req = new XMLHttpRequest();
      }
      catch(e) {}
   }
   // otherwise, try instantiating the ActiveX
   // object for IE.
   else if(window.ActiveXObject) {
      // just because creation of ActiveX objects
      // is supported, doesn't mean the XMLHTTP 
      // object is available. So, let's try it.
      try {
         // try instantiating the newer version
         req = new ActiveXObject("Msxml2.XMLHTTP");
      }
      catch(e) {
         try {
            // otherwise, try the older version
            req = new ActiveXObject("Microsoft.XMLHTTP");
         }
         catch(e) {}
      }
   }
   // req will either be the reference to the 
   // interface or false on failure.
   return req;
}
