<?php

// Include the Pear class
require_once('Text/CAPTCHA.php');

// Set the options for the generated text;
$opts = array(
    'font_size' => 25,
    'font_path' => './',
    'font_file' => 'VeraMono.TTF'
);

// Create a CAPTCHA object
$cap = Text_CAPTCHA::factory('Image');

// Initialize the CAPTCHA object with random text
$r = $cap->init(250,100, null, $opts);

// Check if CAPTCHA object is valid
if (PEAR::isError($r))
{
  echo 'CAPTCHA Generation failed.';
  exit;
}

// Generate the PNG CAPTCHA image
$png = $cap->getCAPTCHAAsPNG();

// Show the image in the browser
header('Content-type: image/png');
echo $png;

?>
