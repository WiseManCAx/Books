<?php

require_once 'phpauthforms.php';

echo "Authentication Successful!";

?>
