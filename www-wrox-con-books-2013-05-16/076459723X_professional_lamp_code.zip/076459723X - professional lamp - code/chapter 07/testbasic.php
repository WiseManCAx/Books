<?php

require_once 'phpauthbasic.php';

echo "Authentication Successful!";

?>
