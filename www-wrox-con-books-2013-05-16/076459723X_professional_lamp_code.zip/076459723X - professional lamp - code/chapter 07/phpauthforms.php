<?php

// Define database constants
define('AUTH_HOST', 'localhost');
define('AUTH_USER', 'WebAuth');
define('AUTH_PASS', 'AuthPass');
define('AUTH_DB',   'WebAuth');


function check_login($username, $password)
{
  $ret = false;
  
  if ($username && $password)
  {
    // Check if login matches database values
    $conn = mysql_connect(AUTH_HOST, AUTH_USER, AUTH_PASS);
    
    if (mysql_select_db(AUTH_DB, $conn))
    {
      // Search for matches
      $result = 
          mysql_query("SELECT COUNT(username) AS ucount
                       FROM Users 
                       WHERE username='" . addslashes($username) . "'
                       AND passwd_md5='" . md5($password) . "'
                       AND passwd_sha1='" . sha1($password) . "'", 
                      $conn);

      // Check if a match was found
      if (($row = mysql_fetch_array($result)) && $row['ucount'])
      {
        $ret = true;
        $_SESSION['username'] = $username;
      }
    }
  
    // Close connection
    mysql_close($conn);
  }
  
  return $ret;
}

session_start();

// Check if using valid credentials
if (!(isset($_SESSION['username']) ||
      check_login($_POST['username'], 
                  $_POST['passwd'])))
{

?>
<form method="post" action="testforms.php">
<label for="username">Username:</label>
<input type="text" id="username" name="username" maxlength="50" /><br />
<label for="passwd">Password:</label>
<input type="password" id="passwd" name="passwd" /><br />
<input type="submit" value="Log in" />
</form>
<?php

}

?>
