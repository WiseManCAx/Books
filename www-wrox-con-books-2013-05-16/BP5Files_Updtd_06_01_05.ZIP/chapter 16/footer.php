</div>
<div class="copyright">
  <?php echo $admin['copyright']['value']; ?>
</div>
</body>
</html>
