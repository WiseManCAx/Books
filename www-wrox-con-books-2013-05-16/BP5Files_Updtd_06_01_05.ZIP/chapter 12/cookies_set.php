<html>
<head>
<title>Beginning PHP5, Apache and MySQL</title>
</head>
<body>
<h1>This is the Set Cookie Page</h1>
<p>
  Your cookies have been set.<br>
  <a href="testcookie.php">Click here</a> to test your cookies.
</p>
</body>
</html>
