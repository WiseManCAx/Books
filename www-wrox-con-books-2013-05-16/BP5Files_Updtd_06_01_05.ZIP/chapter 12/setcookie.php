<html>
<head>
<title>Beginning PHP5, Apache and MySQL</title>
</head>
<body>
<h1>This is the Set Cookie Page</h1>
<p>
  <a href="setcookie_un.php">Click here</a> to set your cookies.
</p>
</body>
</html>
