<html>
<head>
<title>Beginning PHP5, Apache and MySQL</title>
</head>
<body>
<h1>Welcome to the Admin Area!</h1>
<p>
  You are currently not logged in.<br>
  Once logged in, you will have access to your administrator tools.<br>
  <a href="admin_login.php">Click here</a> to login.
</p>
</body>
</html>
