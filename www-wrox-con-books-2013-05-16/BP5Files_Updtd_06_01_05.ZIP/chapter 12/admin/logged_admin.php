<html>
<head>
<title>Beginning PHP5, Apache and MySQL</title>
</head>
<body>
<h1>Welcome to the Admin Area!</h1>
<p>
  You are currently logged in.<br>
  <a href="admin_area.php">Click here</a> 
  to access your administrator tools.
</p>
</body>
</html>
