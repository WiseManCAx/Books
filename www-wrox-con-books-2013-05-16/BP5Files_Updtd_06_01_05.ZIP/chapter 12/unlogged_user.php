<html>
<head>
<title>Beginning PHP5, Apache and MySQL</title>
</head>
<body>
<h1>Welcome to the home page!</h1>
<p>
  You are currently not logged into our system.<br>
  Once logged in, you will have access to your personal area, 
  along with other user information.<br>
  If you have already registered, 
  <a href="user_login.php">click here</a> to login,
  or if would like to create an account, 
  <a href="register.php">click here</a> to register.
</p>
</body>
</html>
