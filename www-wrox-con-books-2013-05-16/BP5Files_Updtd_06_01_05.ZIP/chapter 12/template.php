<?php
include "auth.inc.php";
?>
<html>
<head>
<title>Beginning PHP5, Apache and MySQL</title>
</head>
<body>
<h1>This is the Template Page</h1>
</body>
</html>
