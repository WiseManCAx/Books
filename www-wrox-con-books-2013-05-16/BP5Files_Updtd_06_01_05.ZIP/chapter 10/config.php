<?php

define('SQL_HOST','localhost');
define('SQL_USER','bp5am');
define('SQL_PASS','bp5ampass');
define('SQL_DB','comicsite');

?>
