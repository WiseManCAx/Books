<?php
print_r(gd_info());
?>
