<html>
<head>
<title>My First PHP Program</title>
</head>
<body>
<?php
echo "I'm a lumberjack.";
?>
</body>
</html>
