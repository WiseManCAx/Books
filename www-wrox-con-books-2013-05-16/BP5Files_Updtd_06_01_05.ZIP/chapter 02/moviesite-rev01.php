<html>
<head>
<title>My Movie Site</title>
</head>
<body>
<?php
  define ("FAVMOVIE", "The Life of Brian");
  echo "My favorite movie is ";
  echo FAVMOVIE;
?>
</body>
</html>
