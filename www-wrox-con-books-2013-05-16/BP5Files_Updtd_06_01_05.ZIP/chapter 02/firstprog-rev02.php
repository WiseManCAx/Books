<html>
<head>
<title>My First PHP Program</title>
</head>
<body>
<?php
echo "I'm a lumberjack.";
echo "And I'm okay.";
?>
</body>
</html>
