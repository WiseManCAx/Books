<?php
$flavor[] = "blue raspberry";
$flavor[] = "root beer";
$flavor[] = "pineapple";

sort($flavor);
print_r($flavor);
?>
