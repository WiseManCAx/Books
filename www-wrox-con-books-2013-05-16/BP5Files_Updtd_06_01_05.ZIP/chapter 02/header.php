<div align="center"><font size="4">Welcome to my movie review site!</font>
<br>
<?php
echo "Today is ";
echo date("F d");
echo ", ";
echo date("Y");
?>
</div>
