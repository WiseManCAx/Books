<?php
mail("your@e-mailaddress.com", "Hello World", "Hi, world. Prepare for our arrival. We're starving!");
?>
