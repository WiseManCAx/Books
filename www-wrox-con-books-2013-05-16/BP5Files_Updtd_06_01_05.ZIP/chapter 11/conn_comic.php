<?php
$conn = mysql_connect("localhost", "bp5am", "bp5ampass");
mysql_select_db("postcard", $conn);
?>
